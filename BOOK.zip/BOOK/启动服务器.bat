@echo off
chcp 65001 >nul
echo ========================================
echo    小说阅读器 - 本地服务器启动脚本
echo ========================================
echo.
echo 正在启动本地服务器...
echo 启动成功后，请用浏览器访问：
echo.
echo   本机访问: http://localhost:5001
echo   手机访问: http://%IP%:5001  (需同一WiFi)
echo.
echo 按 Ctrl+C 停止服务器
echo ========================================
echo.

cd /d "%~dp0"
python -m http.server 5001
pause
