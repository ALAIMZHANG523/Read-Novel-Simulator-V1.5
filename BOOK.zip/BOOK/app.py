# -*- coding: utf-8 -*-
"""
小说阅读器 - Flask 后端
技术栈: Python + Flask + SQLite
功能: 书籍管理、章节阅读、阅读进度保存、本地书籍导入
"""

import os
import re
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, jsonify, g, send_from_directory

app = Flask(__name__)
app.config['DATABASE'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'novel.db')
app.config['SECRET_KEY'] = 'novel-reader-secret-key'
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Novel')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 最大50MB


# ==================== 数据库相关 ====================

def get_db():
    """获取数据库连接"""
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


@app.teardown_appcontext
def close_db(exception):
    """关闭数据库连接"""
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    """初始化数据库表结构"""
    db = sqlite3.connect(app.config['DATABASE'])
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    
    # 书籍表
    db.execute('''
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT DEFAULT '未知作者',
            cover TEXT DEFAULT '',
            description TEXT DEFAULT '',
            category TEXT DEFAULT '其他',
            word_count INTEGER DEFAULT 0,
            chapter_count INTEGER DEFAULT 0,
            status TEXT DEFAULT '连载中',
            last_read_chapter_id INTEGER DEFAULT 0,
            last_read_time TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            updated_at TEXT DEFAULT (datetime('now', 'localtime'))
        )
    ''')
    
    # 章节表
    db.execute('''
        CREATE TABLE IF NOT EXISTS chapters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            chapter_number INTEGER NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            word_count INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
        )
    ''')
    
    # 阅读进度表
    db.execute('''
        CREATE TABLE IF NOT EXISTS reading_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            chapter_id INTEGER NOT NULL,
            scroll_position INTEGER DEFAULT 0,
            font_size INTEGER DEFAULT 18,
            theme TEXT DEFAULT 'light',
            updated_at TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
            FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
        )
    ''')
    
    # 书签表
    db.execute('''
        CREATE TABLE IF NOT EXISTS bookmarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            chapter_id INTEGER NOT NULL,
            chapter_title TEXT DEFAULT '',
            note TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
            FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
        )
    ''')
    
    db.commit()
    db.close()


# ==================== 页面路由 ====================

@app.route('/manifest.json')
def manifest():
    """PWA manifest"""
    return send_from_directory('static', 'manifest.json', mimetype='application/json')


@app.route('/sw.js')
def service_worker():
    """Service Worker"""
    return send_from_directory('static', 'sw.js', mimetype='application/javascript')


@app.route('/')
def index():
    """首页 - 书架"""
    return render_template('index.html')


@app.route('/read/<int:book_id>')
def read_book(book_id):
    """阅读页面"""
    return render_template('read.html', book_id=book_id)


@app.route('/catalog/<int:book_id>')
def catalog(book_id):
    """目录页面"""
    return render_template('catalog.html', book_id=book_id)


@app.route('/bookmarks')
def bookmarks_page():
    """书签页面"""
    return render_template('bookmarks.html')


@app.route('/profile')
def profile_page():
    """个人中心页面"""
    return render_template('profile.html')


# ==================== API 接口 ====================

@app.route('/api/books')
def api_books():
    """获取书籍列表"""
    db = get_db()
    books = db.execute(
        'SELECT * FROM books ORDER BY updated_at DESC'
    ).fetchall()
    
    result = []
    for book in books:
        # 获取第一章ID
        first_chapter = db.execute(
            'SELECT id FROM chapters WHERE book_id = ? ORDER BY chapter_number LIMIT 1',
            (book['id'],)
        ).fetchone()
        
        result.append({
            'id': book['id'],
            'title': book['title'],
            'author': book['author'],
            'cover': book['cover'],
            'description': book['description'],
            'category': book['category'],
            'word_count': book['word_count'],
            'chapter_count': book['chapter_count'],
            'status': book['status'],
            'last_read_chapter_id': book['last_read_chapter_id'],
            'first_chapter_id': first_chapter['id'] if first_chapter else 0,
            'last_read_time': book['last_read_time'],
            'updated_at': book['updated_at']
        })
    
    return jsonify({'code': 0, 'data': result})


@app.route('/api/book/<int:book_id>')
def api_book_detail(book_id):
    """获取书籍详情"""
    db = get_db()
    book = db.execute('SELECT * FROM books WHERE id = ?', (book_id,)).fetchone()
    
    if not book:
        return jsonify({'code': 404, 'msg': '书籍不存在'})
    
    # 获取阅读进度
    progress = db.execute(
        'SELECT * FROM reading_progress WHERE book_id = ?',
        (book_id,)
    ).fetchone()
    
    first_chapter = db.execute(
        'SELECT id FROM chapters WHERE book_id = ? ORDER BY chapter_number LIMIT 1',
        (book_id,)
    ).fetchone()
    
    return jsonify({
        'code': 0,
        'data': {
            'id': book['id'],
            'title': book['title'],
            'author': book['author'],
            'cover': book['cover'],
            'description': book['description'],
            'category': book['category'],
            'word_count': book['word_count'],
            'chapter_count': book['chapter_count'],
            'status': book['status'],
            'first_chapter_id': first_chapter['id'] if first_chapter else 0,
            'progress': {
                'chapter_id': progress['chapter_id'] if progress else 0,
                'scroll_position': progress['scroll_position'] if progress else 0,
                'font_size': progress['font_size'] if progress else 18,
                'theme': progress['theme'] if progress else 'light'
            }
        }
    })


@app.route('/api/chapters/<int:book_id>')
def api_chapters(book_id):
    """获取章节列表"""
    db = get_db()
    chapters = db.execute(
        'SELECT id, book_id, chapter_number, title, word_count FROM chapters WHERE book_id = ? ORDER BY chapter_number',
        (book_id,)
    ).fetchall()
    
    result = []
    for ch in chapters:
        result.append({
            'id': ch['id'],
            'book_id': ch['book_id'],
            'chapter_number': ch['chapter_number'],
            'title': ch['title'],
            'word_count': ch['word_count']
        })
    
    return jsonify({'code': 0, 'data': result})


@app.route('/api/chapter/<int:chapter_id>')
def api_chapter_content(chapter_id):
    """获取章节内容"""
    db = get_db()
    chapter = db.execute('SELECT * FROM chapters WHERE id = ?', (chapter_id,)).fetchone()
    
    if not chapter:
        return jsonify({'code': 404, 'msg': '章节不存在'})
    
    # 获取上一章和下一章
    prev_chapter = db.execute(
        'SELECT id FROM chapters WHERE book_id = ? AND chapter_number < ? ORDER BY chapter_number DESC LIMIT 1',
        (chapter['book_id'], chapter['chapter_number'])
    ).fetchone()
    
    next_chapter = db.execute(
        'SELECT id FROM chapters WHERE book_id = ? AND chapter_number > ? ORDER BY chapter_number LIMIT 1',
        (chapter['book_id'], chapter['chapter_number'])
    ).fetchone()
    
    return jsonify({
        'code': 0,
        'data': {
            'id': chapter['id'],
            'book_id': chapter['book_id'],
            'chapter_number': chapter['chapter_number'],
            'title': chapter['title'],
            'content': chapter['content'],
            'word_count': chapter['word_count'],
            'prev_id': prev_chapter['id'] if prev_chapter else 0,
            'next_id': next_chapter['id'] if next_chapter else 0
        }
    })


@app.route('/api/progress/save', methods=['POST'])
def api_save_progress():
    """保存阅读进度"""
    data = request.get_json()
    book_id = data.get('book_id')
    chapter_id = data.get('chapter_id')
    scroll_position = data.get('scroll_position', 0)
    font_size = data.get('font_size', 18)
    theme = data.get('theme', 'light')
    
    if not book_id or not chapter_id:
        return jsonify({'code': 400, 'msg': '参数错误'})
    
    db = get_db()
    
    # 检查是否已有进度记录
    existing = db.execute(
        'SELECT id FROM reading_progress WHERE book_id = ?',
        (book_id,)
    ).fetchone()
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    if existing:
        db.execute('''
            UPDATE reading_progress 
            SET chapter_id = ?, scroll_position = ?, font_size = ?, theme = ?, updated_at = ?
            WHERE book_id = ?
        ''', (chapter_id, scroll_position, font_size, theme, now, book_id))
    else:
        db.execute('''
            INSERT INTO reading_progress (book_id, chapter_id, scroll_position, font_size, theme, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (book_id, chapter_id, scroll_position, font_size, theme, now))
    
    # 更新书籍的最后阅读信息
    db.execute('''
        UPDATE books SET last_read_chapter_id = ?, last_read_time = ?, updated_at = ? WHERE id = ?
    ''', (chapter_id, now, now, book_id))
    
    db.commit()
    return jsonify({'code': 0, 'msg': '保存成功'})


@app.route('/api/progress/<int:book_id>')
def api_get_progress(book_id):
    """获取阅读进度"""
    db = get_db()
    progress = db.execute(
        'SELECT * FROM reading_progress WHERE book_id = ?',
        (book_id,)
    ).fetchone()
    
    if not progress:
        return jsonify({'code': 0, 'data': {
            'chapter_id': 0,
            'scroll_position': 0,
            'font_size': 18,
            'theme': 'light'
        }})
    
    return jsonify({
        'code': 0,
        'data': {
            'chapter_id': progress['chapter_id'],
            'scroll_position': progress['scroll_position'],
            'font_size': progress['font_size'],
            'theme': progress['theme']
        }
    })


@app.route('/api/bookmarks')
def api_bookmarks():
    """获取书签列表"""
    db = get_db()
    bookmarks = db.execute('''
        SELECT bm.*, b.title as book_title 
        FROM bookmarks bm 
        LEFT JOIN books b ON bm.book_id = b.id 
        ORDER BY bm.created_at DESC
    ''').fetchall()
    
    result = []
    for bm in bookmarks:
        result.append({
            'id': bm['id'],
            'book_id': bm['book_id'],
            'chapter_id': bm['chapter_id'],
            'chapter_title': bm['chapter_title'],
            'book_title': bm['book_title'],
            'note': bm['note'],
            'created_at': bm['created_at']
        })
    
    return jsonify({'code': 0, 'data': result})


@app.route('/api/bookmark/add', methods=['POST'])
def api_add_bookmark():
    """添加书签"""
    data = request.get_json()
    book_id = data.get('book_id')
    chapter_id = data.get('chapter_id')
    chapter_title = data.get('chapter_title', '')
    note = data.get('note', '')
    
    if not book_id or not chapter_id:
        return jsonify({'code': 400, 'msg': '参数错误'})
    
    db = get_db()
    
    # 检查是否已存在相同书签
    existing = db.execute(
        'SELECT id FROM bookmarks WHERE book_id = ? AND chapter_id = ?',
        (book_id, chapter_id)
    ).fetchone()
    
    if existing:
        return jsonify({'code': 400, 'msg': '已添加过该书签'})
    
    db.execute('''
        INSERT INTO bookmarks (book_id, chapter_id, chapter_title, note)
        VALUES (?, ?, ?, ?)
    ''', (book_id, chapter_id, chapter_title, note))
    
    db.commit()
    return jsonify({'code': 0, 'msg': '添加成功'})


@app.route('/api/bookmark/delete/<int:bookmark_id>', methods=['DELETE'])
def api_delete_bookmark(bookmark_id):
    """删除书签"""
    db = get_db()
    db.execute('DELETE FROM bookmarks WHERE id = ?', (bookmark_id,))
    db.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


@app.route('/api/book/check_bookmark/<int:book_id>/<int:chapter_id>')
def api_check_bookmark(book_id, chapter_id):
    """检查章节是否已添加书签"""
    db = get_db()
    bookmark = db.execute(
        'SELECT id FROM bookmarks WHERE book_id = ? AND chapter_id = ?',
        (book_id, chapter_id)
    ).fetchone()
    return jsonify({'code': 0, 'data': {'exists': bookmark is not None}})


# ==================== 初始化数据 ====================

def seed_sample_data():
    """添加示例小说数据"""
    db = sqlite3.connect(app.config['DATABASE'])
    db.row_factory = sqlite3.Row
    
    # 检查是否已有数据
    count = db.execute('SELECT COUNT(*) as cnt FROM books').fetchone()['cnt']
    if count > 0:
        db.close()
        return
    
    # 示例小说 1: 武侠小说
    book1_id = db.execute('''
        INSERT INTO books (title, author, cover, description, category, status)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        '剑啸江湖',
        '金庸风',
        '📚',
        '一个少年剑客闯荡江湖的传奇故事。他从无名小卒成长为一代大侠，历经爱恨情仇，最终悟出剑道真谛。',
        '武侠仙侠',
        '连载中'
    )).lastrowid
    
    chapters_1 = [
        ('第一章 少年出山', '''
　　青山叠翠，云雾缭绕。

　　在这座名为"青云山"的深处，坐落着一个小小的村落。村落不大，只有几十户人家，村民们世代以采药打猎为生，过着与世隔绝的生活。

　　村东头有一间破旧的茅屋，里面住着一个叫李云飞的少年。李云飞今年十六岁，父母早亡，从小跟着村里的老猎人长大。老猎人去年冬天上山打猎时不幸摔断了腿，从此便卧床不起，家里的重担就全压在了李云飞的肩上。

　　这天清晨，天刚蒙蒙亮，李云飞就背着药篓上了山。他要去采一种叫"冰灵草"的草药，据说这种草药能治老猎人的腿伤。

　　"云飞，你等等我！"身后传来一个清脆的声音。

　　李云飞回头一看，只见一个穿着蓝布衣裙的少女正快步向他跑来。少女名叫林婉儿，是村长的女儿，也是李云飞从小一起长大的玩伴。

　　"婉儿，你怎么来了？"李云飞停下脚步，有些惊讶地问。

　　"我爹说冰灵草长在悬崖边上，太危险了，让我来帮你。"林婉儿跑到他面前，喘着气说，脸上带着两团红晕。

　　李云飞心中一暖，但还是摇摇头说："不行，太危险了，你还是回去吧。"

　　"我不回去！"林婉儿倔强地说，"我们从小一起长大，什么事没一起经历过？不就是采个药嘛，有什么好怕的。"

　　李云飞看着她坚定的眼神，知道劝不动她，只好无奈地笑了笑："好吧，那你跟紧我，千万小心。"

　　两人一路向山上走去。青云山山势险峻，越往上走，路越难走。到了半山腰，已经没有现成的路了，只能在茂密的丛林中穿行。

　　"云飞，你说冰灵草真的能治好王爷爷的腿吗？"林婉儿一边拨开挡路的树枝，一边问。

　　"我也不知道，"李云飞老实地说，"不过张大夫说，冰灵草是治疗骨伤的圣药，如果能找到的话，王爷爷的腿就有希望了。"

　　"那就好，"林婉儿点点头，"我们一定能找到的。"

　　又走了大约一个时辰，两人终于来到了一处悬崖边。这里是青云山最险峻的地方，脚下就是万丈深渊，站在崖边往下看，让人头晕目眩。

　　"冰灵草就长在那！"李云飞指着崖壁上的一株银白色的小草兴奋地说。

　　那株小草长在崖壁的一个石缝里，距离崖顶大约有三丈多远，周围光秃秃的，根本没有可以落脚的地方。

　　"这...这怎么采啊？"林婉儿看着那险峻的位置，不禁有些担心，"太危险了，云飞，我们还是回去吧。"

　　"不行，"李云飞摇摇头，"王爷爷的腿不能再拖了。我必须把它采回来。"

　　"可是..."

　　"放心吧，我从小在山里长大，爬山采药是家常便饭，不会有事的。"李云飞安慰她说。

　　说完，李云飞解下腰间的麻绳，一头系在旁边的大树上，另一头系在自己腰上。然后他小心翼翼地攀着崖壁，慢慢向下移动。

　　"小心点！"林婉儿趴在崖边，紧张地看着他，手心都攥出了汗。

　　李云飞手脚并用，一点一点地向冰灵草靠近。崖壁上布满了青苔，滑得很，好几次他都差点失足掉下去。林婉儿在上面看得心惊胆战，却又不敢大声喊，怕分了他的心。

　　终于，李云飞够到了冰灵草。他小心翼翼地将草药连根挖起，放进怀里，然后开始向上攀爬。

　　就在他快要爬到崖顶的时候，脚下的一块石头突然松动了。

　　"啊！"李云飞惊呼一声，身体向下坠去。

　　"云飞！"林婉儿吓得大叫起来。

　　好在麻绳及时绷紧，李云飞悬在了半空中，来回晃荡。他定了定神，深吸一口气，继续向上爬。

　　终于，李云飞爬上了崖顶。他瘫坐在地上，大口喘着气，后背已经被汗水湿透了。

　　"你吓死我了！"林婉儿扑过来，眼泪都快掉下来了，"以后不许你再这么冒险了！"

　　李云飞从怀里掏出冰灵草，笑着说："你看，采到了。"

　　林婉儿看着他手中的冰灵草，又看看他脸上的笑容，不由得破涕为笑："你呀，真是不要命了。"

　　两人休息了一会儿，便起身往回走。刚走出没多远，李云飞突然停住了脚步。

　　"怎么了？"林婉儿疑惑地问。

　　"嘘——"李云飞做了个噤声的手势，"你听，好像有声音。"

　　林婉儿侧耳细听，果然听到远处传来一阵打斗声，中间还夹杂着人的喊叫声。

　　"好像是从前面的山谷传过来的。"李云飞说。

　　"我们快走吧，别管闲事。"林婉儿有些害怕地说。她从小在村子里长大，哪里见过这种场面。

　　李云飞犹豫了一下，点点头说："好，我们走。"

　　就在两人准备离开的时候，打斗声突然停了。紧接着，一个浑身是血的黑衣人从树林里冲了出来，径直向他们这边跑来。

　　黑衣人看到他们，眼中闪过一丝精光，沉声喝道："你们是什么人？"

　　李云飞将林婉儿护在身后，警惕地看着黑衣人："我们是山下村子里的，上山采药。"

　　黑衣人上下打量了他们一眼，似乎在判断他们说的是不是真话。就在这时，后面又追来了几个人，都是一身青色劲装，手持利剑。

　　"魔教妖人，看你往哪里跑！"为首的青衫人厉声喝道。

　　黑衣人冷哼一声，从怀里掏出一个小瓶子，扔向身后。"砰"的一声，瓶子炸开，冒出一股黑烟。

　　"不好，是毒烟！快闭气！"青衫人大喊。

　　趁着黑烟弥漫的机会，黑衣人一把抓住李云飞的胳膊，低声说："跟我走！"

　　李云飞只觉得一股强大的力量传来，身不由己地被黑衣人拖着向前跑去。林婉儿惊呼一声，也连忙跟了上去。
        '''.strip()),
        
        ('第二章 神秘黑衣人', '''
　　黑衣人拖着李云飞在山林中飞速穿行，速度快得惊人。李云飞只觉得耳边风声呼呼作响，两旁的树木飞速向后倒退。他长这么大，从来没见过跑得这么快的人。

　　跑了大约一炷香的时间，黑衣人终于停了下来。这里是一个隐蔽的山洞，洞口被藤蔓遮掩着，如果不仔细看，根本发现不了。

　　黑衣人松开李云飞的胳膊，踉跄了一下，扶住洞壁才没有摔倒。他的伤势显然很重，嘴角不断有鲜血溢出。

　　"你...你是谁？"李云飞喘着气问。刚才被拖着跑了这么远，他已经累得不行了。

　　黑衣人没有回答他的问题，只是靠在洞壁上，闭目调息。过了好一会儿，他才睁开眼睛，看向李云飞。

　　"小子，你叫什么名字？"黑衣人问。他的声音沙哑，却带着一种不怒自威的气势。

　　"我...我叫李云飞。"李云飞如实回答。他能感觉到，这个黑衣人虽然受了重伤，但身上散发出的那股气势，却让人不由自主地感到畏惧。

　　"李云飞..."黑衣人喃喃重复了一遍，目光在他脸上停留了很久，似乎在回忆什么。

　　"你...你受伤了，要不要紧？"李云飞试探着问。虽然不知道这个人是好是坏，但看他伤得这么重，李云飞心里还是有些不忍。

　　黑衣人看了他一眼，嘴角微微上扬，似乎觉得有些好笑："你不怕我？"

　　"怕..."李云飞老实地说，"不过你受伤了，我总不能见死不救吧。"

　　黑衣人愣了一下，随即哈哈大笑起来。笑声牵动了伤口，他忍不住咳嗽了几声，咳出了几口血。

　　"好，好一个见死不救。"黑衣人止住笑，看着李云飞，眼神中多了几分赞许，"小子，你很对我胃口。"

　　就在这时，林婉儿也气喘吁吁地跑了过来。她跑得比李云飞慢，所以晚了一会儿才到。

　　"云飞，你没事吧？"林婉儿跑到李云飞身边，上下打量着他，生怕他受伤。

　　"我没事。"李云飞摇摇头，指了指黑衣人，"他受伤了。"

　　林婉儿这才注意到旁边的黑衣人，吓得躲到李云飞身后，露出半个脑袋，怯生生地看着他。

　　黑衣人看了林婉儿一眼，没有说话，又闭上眼睛开始调息。

　　李云飞拉着林婉儿走到一边，压低声音说："婉儿，你先回去吧，免得你爹担心。"

　　"那你呢？"林婉儿问。

　　"我...我再待一会儿。"李云飞看了一眼黑衣人，"他伤得很重，我怕他有危险。"

　　"可是..."林婉儿想说什么，但看到李云飞坚定的眼神，最终还是点点头，"好吧，那我先回去，你自己小心点。"

　　"嗯，"李云飞点点头，"回去路上注意安全。"

　　林婉儿依依不舍地离开了。

　　山洞里只剩下李云飞和黑衣人两个人。黑衣人闭着眼睛，似乎在运功疗伤。李云飞不敢打扰他，就坐在旁边守着。

　　不知过了多久，黑衣人终于睁开了眼睛。他的脸色比刚才好了一些，但依然很苍白。

　　"小子，你为什么不走？"黑衣人问。

　　"我..."李云飞想了想，说，"我看你一个人在这里，又受了伤，不太放心。"

　　黑衣人沉默了一会儿，突然说："你想不想学武功？"

　　"武功？"李云飞愣住了。他从小在山村长大，对江湖上的事一无所知，但也听说过武功高强的人能够飞檐走壁，行侠仗义。每个少年心中都有一个武侠梦，李云飞也不例外。

　　"想...想啊。"李云飞有些激动地说，"可是...我能学吗？"

　　"为什么不能？"黑衣人反问。

　　"我...我什么都不会，而且..."李云飞有些不好意思地说，"我家里很穷，没钱拜师。"

　　黑衣人又笑了："钱？在我眼里，钱算什么东西。只要你想学，我可以教你。"

　　"真的？"李云飞瞪大了眼睛，不敢相信自己的耳朵。

　　"当然是真的。"黑衣人说，"不过，学武是很苦的，你怕不怕苦？"

　　"不怕！"李云飞毫不犹豫地说，"再苦我也不怕！"

　　"好！"黑衣人满意地点点头，"从今天起，你就是我萧远山的徒弟了。"

　　"萧远山？"李云飞觉得这个名字有点耳熟，但一时想不起来在哪里听过。

　　"怎么，你听说过我的名字？"萧远山问。

　　"好像...好像在哪里听过。"李云飞挠挠头，不好意思地说，"不过我记不清了。"

　　萧远山哈哈一笑："记不清就算了。反正从今往后，你只要知道我是你师父就行了。"

　　"是，师父！"李云飞连忙跪下，恭恭敬敬地磕了三个响头。

　　"好，好，好。"萧远山连说了三个好字，看起来很是高兴，"没想到我萧远山隐居多年，竟然还能收到你这么个徒弟。也算是缘分吧。"

　　顿了顿，萧远山又说："不过，关于我的身份，你不要对外人提起，包括你的那个小女朋友，明白吗？"

　　"明白。"李云飞连忙点头，虽然他不太明白为什么不能说，但师父说的话肯定有道理。

　　"还有，"萧远山继续说，"我教你武功的事，也不能让别人知道。每天晚上，你到这个山洞里来，我教你两个时辰。"

　　"好的，师父。"李云飞认真地说。

　　萧远山满意地点点头："好，那我们今天就开始。不过在教你武功之前，我要先给你讲讲江湖上的事，让你对这个世界有个了解。"

　　接下来，萧远山就给李云飞讲起了江湖中的种种。从武林各大门派，到各种神奇的武功秘籍，再到江湖中的恩怨情仇，李云飞听得如痴如醉。他从来不知道，原来外面的世界这么精彩。

　　讲了大约一个时辰，萧远山停了下来。

　　"好了，今天就讲这么多。"萧远山说，"接下来，我教你一套基础的吐纳法门。这是修炼内功的基础，你要好好练。"

　　说完，萧远山就详细地给李云飞讲解了吐纳的方法和口诀。李云飞听得很认真，把每一个字都记在了心里。

　　"来，你试试看。"萧远山说。

　　李云飞按照萧远山教的方法，盘膝坐下，开始吐纳。一开始，他感觉不到任何变化，但练了一会儿，他突然感觉到小腹中有一股暖流在缓缓流动。

　　"师父，我感觉到了！"李云飞惊喜地说，"我肚子里有一股热气！"

　　萧远山眼中闪过一丝惊讶："这么快就有气感了？不错，不错，你的资质比我想象的还要好。"

　　其实李云飞不知道，他从小在山里长大，每天采药打猎，身体素质远超常人。而且他心思单纯，没有杂念，所以修炼起来事半功倍。

　　"继续练，不要分心。"萧远山说，"记住，习武一途，贵在坚持。切不可三天打鱼，两天晒网。"

　　"是，师父！"李云飞收敛心神，继续修炼。

　　不知不觉，天已经黑了。李云飞才依依不舍地停了下来。

　　"师父，我该回去了，不然王爷爷该担心了。"李云飞说。

　　"嗯，去吧。"萧远山点点头，"记住，今天教你的吐纳法门，回去以后也要勤加练习。每天晚上到这里来，我教你新的东西。"

　　"好的，师父。"李云飞恭敬地行了个礼，然后离开了山洞。

　　走在回家的路上，李云飞的心情久久不能平静。他有一种预感，自己的人生，将从此刻开始，变得不一样了。
        '''.strip()),
        
        ('第三章 初窥门径', '''
　　回到村里，天已经完全黑了。李云飞先去看望了老猎人王大爷，把冰灵草交给了王奶奶，然后才回到自己的茅屋。

　　简单吃了点东西，李云飞就迫不及待地盘膝坐下，开始修炼今天萧远山教给他的吐纳法门。

　　一开始，那股暖流还很微弱，若有若无。但随着李云飞不断地吐纳，那股暖流越来越明显，在他的经脉中缓缓流动。虽然流动的速度很慢，但李云飞能清晰地感觉到，每运转一个周天，那股暖流就会壮大一分。

　　不知不觉，一夜过去了。当窗外传来第一声鸡叫的时候，李云飞才从修炼中醒来。

　　他站起身来，活动了一下手脚，只觉得浑身舒畅，精神饱满，一点都不觉得累。而且他发现，自己的视力和听力似乎都比以前好了很多。远处的山，以前看起来朦朦胧胧的，现在却能看清山上的树木。甚至连院子里蚂蚁爬动的声音，他都能听得一清二楚。

　　"这就是武功的神奇吗？"李云飞心中又惊又喜。

　　他现在更期待晚上去见师父了。

　　白天，李云飞照常上山打猎采药。他发现，有了内功之后，爬山比以前轻松多了，以前要走一个时辰的路，现在半个时辰就到了。而且他的力气也大了很多，以前搬不动的大石头，现在轻轻一推就动了。

　　"奇怪，云飞，你今天怎么这么有劲？"一起上山打猎的二柱子疑惑地问。

　　"有吗？"李云飞笑了笑，"可能是昨晚睡得好吧。"

　　"哦。"二柱子也没多想，继续往前走。

　　好不容易熬到了晚上，李云飞匆匆吃了晚饭，就借口出去散步，溜出了村子，向青云山深处走去。

　　来到山洞的时候，萧远山已经在等着他了。

　　"师父。"李云飞恭敬地行礼。

　　"嗯，来了。"萧远山点点头，"昨天教你的吐纳法门，练得怎么样了？"

　　"我...我练了一晚上，感觉那股气比昨天强了一些。"李云飞如实回答。

　　"一晚上？"萧远山愣了一下，"你是说，你昨晚一夜没睡，一直在练？"

　　"是啊，"李云飞点点头，"我越练越精神，一点都不困。"

　　萧远山沉默了片刻，然后叹了口气说："你小子，还真是个练武的奇才。想当年，我花了整整三个月才练出气感，你竟然一天就有了。而且一夜之间，内力就有了小成。"

　　李云飞不好意思地笑了笑："是师父教得好。"

　　"少拍马屁。"萧远山虽然嘴上这么说，但脸上还是露出了欣慰的笑容，"好了，闲话少说，今天我教你一套掌法，名叫'青云掌'。这套掌法虽然只是入门级的武功，但配合内力使用，威力也不容小觑。"

　　说完，萧远山就站起身来，开始演示青云掌的招式。

　　只见他身形飘动，双掌翻飞，时而如行云流水，时而如雷霆万钧。掌风所到之处，山洞里的碎石都被吹得四处飞散。

　　李云飞看得目瞪口呆。他从来没想过，人的掌力竟然能这么强。

　　"看清楚了吗？"萧远山收功站定，气不喘心不跳，仿佛刚才那一番激烈的演示对他来说根本不算什么。

　　"看...看清楚了。"李云飞咽了口唾沫说。

　　"好，那你练一遍给我看看。"萧远山说。

　　李云飞点点头，学着萧远山的样子，开始一招一式地练了起来。虽然他的动作还有些生疏，力道也差得远，但每一招每一式都有模有样，没有出错。

　　萧远山在旁边看着，眼中的惊讶越来越浓。他本以为李云飞至少要练个三五遍才能记住招式，没想到他只看了一遍就全记住了。虽然动作还不够流畅，但假以时日，必成大器。

　　"好，很好。"萧远山忍不住夸赞道，"云飞，你的天赋，是我这辈子见过最好的。"

　　李云飞被夸得有些不好意思，挠挠头说："师父过奖了。"

　　"这不是夸奖，是事实。"萧远山正色说，"不过，天赋再好，也需要努力。古往今来，多少天纵奇才，最后都因为骄傲自满而一事无成。你明白吗？"

　　"弟子明白。"李云飞认真地说，"弟子一定不会让师父失望的。"

　　"好，有你这句话就够了。"萧远山满意地点点头，"接下来的日子，我会把我毕生所学，慢慢地都传授给你。至于你能达到什么高度，就看你自己的造化了。"

　　从那天起，李云飞开始了白天干活、晚上练功的生活。虽然每天都很忙很累，但他却觉得很充实，很快乐。

　　日子一天天过去，李云飞的武功也在飞速进步着。短短一个月的时间，他的内力已经有了相当的基础，青云掌也练得炉火纯青。萧远山又开始教他轻功和剑法。

　　李云飞最喜欢的是剑法。萧远山教给他的剑法名叫"流云剑法"，招式飘逸灵动，如行云流水一般。李云飞每天晚上都要练上几百遍，直到把每一招每一式都刻在骨子里。

　　这天晚上，李云飞正在练剑，萧远山突然开口说："云飞，停一下。"

　　李云飞收剑而立，疑惑地看着师父："师父，怎么了？"

　　"你的剑法，已经练得差不多了。"萧远山说，"基础的东西，我已经教完了。接下来，就要靠你自己去领悟了。"

　　"啊？"李云飞愣了一下，"师父，你的意思是..."

　　"我的意思是，你该出去闯荡江湖了。"萧远山说，"待在这个小山村里，你的武功永远不会有真正的进步。只有出去历练，经历各种人和事，你的武功才能更上一层楼。"

　　李云飞沉默了。他知道师父说的是对的，但一想到要离开这个生活了十六年的地方，离开王爷爷，离开婉儿，他的心里就有些舍不得。

　　"怎么，舍不得？"萧远山问。

　　"嗯。"李云飞点点头，没有否认。

　　"男儿志在四方，"萧远山说，"总待在这个小地方，能有什么出息？等你将来功成名就了，再回来也不迟。"

　　李云飞想了想，觉得师父说得有道理。他深吸一口气，抬起头说："师父，我明白了。我出去闯荡江湖！"

　　"好！"萧远山满意地点点头，"这才是我萧远山的徒弟！"

　　"不过，师父，"李云飞又问，"我走了，你怎么办？"

　　"我？"萧远山笑了笑，"我一个老头子，在哪都一样。你不用管我。"

　　"可是你的伤..."李云飞有些担心地说。这一个月来，萧远山的伤势虽然有所好转，但依然没有完全康复。

　　"我的伤不碍事，"萧远山说，"再静养一段时间就好了。倒是你，出去以后，万事小心。江湖险恶，人心叵测，不要轻易相信别人。"

　　"弟子记住了。"李云飞认真地点点头。

　　"还有，"萧远山从怀里掏出一本泛黄的书册，递给李云飞，"这是我毕生修炼的内功心法'太清诀'，你带在身边，有空就看看。记住，这套心法博大精深，你要循序渐进，不可急于求成。"

　　李云飞双手接过书册，郑重地说："弟子一定好好修炼，不辜负师父的期望。"

　　"嗯。"萧远山点点头，又从腰间解下一柄长剑，"这把剑，是我年轻时用的佩剑，名叫'青锋'。今天，我把它送给你。希望你能用它，行侠仗义，不枉我教你一场。"

　　李云飞接过青锋剑，只觉得入手沉重，剑鞘上刻着精美的花纹，一看就不是凡品。他"扑通"一声跪倒在地，哽咽着说："师父..."

　　"好了，男子汉大丈夫，哭什么。"萧远山摆摆手，"你什么时候走？"

　　"我...我再待几天，安排一下村里的事。"李云飞擦了擦眼睛说。

　　"嗯，去吧。"萧远山转过身去，背对着李云飞，"记住，不到万不得已，不要暴露你是我徒弟的身份。"

　　"弟子明白。"李云飞重重地磕了三个响头，然后拿着剑和书册，依依不舍地离开了山洞。

　　看着李云飞离去的背影，萧远山的眼中闪过一丝复杂的神色。他喃喃自语道："云飞，希望你不要让我失望。这江湖的未来，终究是你们年轻人的..."
        '''.strip())
    ]
    
    for i, (title, content) in enumerate(chapters_1):
        word_count = len(content.replace(' ', '').replace('\n', ''))
        db.execute('''
            INSERT INTO chapters (book_id, chapter_number, title, content, word_count)
            VALUES (?, ?, ?, ?, ?)
        ''', (book1_id, i + 1, title, content, word_count))
    
    # 更新书籍章节数和字数
    db.execute('''
        UPDATE books SET chapter_count = (SELECT COUNT(*) FROM chapters WHERE book_id = ?),
        word_count = (SELECT SUM(word_count) FROM chapters WHERE book_id = ?)
        WHERE id = ?
    ''', (book1_id, book1_id, book1_id))
    
    # 示例小说 2: 都市小说
    book2_id = db.execute('''
        INSERT INTO books (title, author, cover, description, category, status)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        '都市之最强医神',
        '夜行者',
        '📖',
        '一个身怀绝技的小医生，在繁华都市中悬壶济世，救死扶伤。他用神奇的医术，征服了无数人的心，也收获了属于自己的爱情和事业。',
        '都市异能',
        '连载中'
    )).lastrowid
    
    chapters_2 = [
        ('第一章 实习生林辰', '''
　　清晨，阳光透过窗户洒进病房，给洁白的墙壁镀上了一层金边。

　　林辰站在病房里，认真地听着主治医生的查房指导。他是江城市第一人民医院的实习医生，今天是他来心内科实习的第三十天。

　　"林辰，你来说说，这个病人的情况怎么样？"主治医生王主任突然点名问他。

　　林辰上前一步，看了看病历，然后有条不紊地说："患者男性，65岁，因胸闷气短三天入院。心电图显示ST段压低，心肌酶谱偏高，初步诊断为冠心病，不稳定型心绞痛。目前给予抗血小板、调脂、扩冠等治疗，病情基本稳定。"

　　王主任点点头："嗯，说得不错。那你说说，下一步的治疗方案是什么？"

　　"我建议尽快做冠脉造影，明确血管狭窄的程度。如果狭窄超过70%，可以考虑植入支架。"林辰回答。

　　"很好。"王主任满意地点点头，"看来你这一个月没白学。继续努力。"

　　"谢谢王主任。"林辰谦虚地笑了笑。

　　查完房，林辰回到医生办公室，开始写病历。他是从农村出来的孩子，考上了江城医科大学，凭着优异的成绩，获得了在市一院实习的机会。他很珍惜这个机会，每天都努力学习，希望能成为一名优秀的医生。

　　"林辰，又在写病历啊？"一个清脆的声音在旁边响起。

　　林辰抬头一看，是护士苏小雅。苏小雅是心内科的护士，长得很漂亮，性格也很开朗，和林辰关系不错。

　　"是啊，"林辰笑了笑，"今天新收了好几个病人，病历得赶紧写完。"

　　"你也太拼了吧，"苏小雅撇撇嘴，"天天加班，小心身体吃不消。对了，今晚科室聚餐，你去不去？"

　　"今晚啊..."林辰犹豫了一下。他今晚本来打算去图书馆看书的，但转念一想，自己来科室一个月了，还没参加过集体活动，不去不太好。

　　"去吧，在哪里？"林辰问。

　　"就在医院旁边的那家川菜馆，"苏小雅高兴地说，"晚上六点，不见不散哦。"

　　"好的。"林辰点点头。

　　就在这时，护士站的呼叫铃突然响了。苏小雅接起电话，脸色一变："什么？好，我马上来！"

　　"怎么了？"林辰问。

　　"3床病人突然昏迷了！"苏小雅着急地说，"我去叫王主任！"

　　"我先过去看看！"林辰说完，立刻向3床病房跑去。

　　3床是一个六十多岁的老人，昨天刚入院的。林辰冲进病房的时候，只见老人躺在床上，双目紧闭，脸色青紫，已经没有了呼吸。

　　林辰上前一摸颈动脉，没有搏动。他立刻判断：心跳骤停！

　　"快，抢救！"林辰大喊一声，立刻开始胸外按压。

　　旁边的护士也反应过来，连忙推来了抢救车。

　　"肾上腺素一支，静推！"

　　"阿托品一支，静推！"

　　"准备除颤！"

　　林辰一边做胸外按压，一边沉着地下达指令。虽然他只是个实习生，但此刻的他，却比很多老医生还要镇定。

　　苏小雅带着王主任赶过来的时候，抢救已经进行了五分钟。王主任看了看监护仪，又看了看林辰，点了点头："继续。"

　　十分钟过去了，病人还是没有反应。旁边的护士都有些绝望了，一般来说，心跳骤停抢救超过十分钟还没复苏的话，希望就很渺茫了。

　　但林辰没有放弃。他咬着牙，一下一下地做着胸外按压。汗水从他的额头滴落，浸湿了白大褂的领口。

　　"林辰，要不...算了吧。"苏小雅小声说，声音有些哽咽。

　　林辰没有说话，只是摇了摇头，继续按压。

　　就在这时，奇迹发生了。监护仪上原本是一条直线的心电图，突然出现了波动。

　　"有了！有心跳了！"一个护士惊喜地喊道。

　　林辰松了一口气，停下来的时候，才发现自己的胳膊已经酸得抬不起来了。

　　王主任上前检查了一下病人的情况，对林辰说："干得好，林辰。"

　　"这是我应该做的。"林辰喘着气说。

　　病人很快被推进了ICU。回到办公室，大家都用敬佩的眼光看着林辰。

　　"林辰，你太厉害了！"苏小雅崇拜地说，"我还是第一次看到有人能把心跳骤停这么久的病人救回来。"

　　"运气好而已。"林辰谦虚地说。

　　"什么运气好，"王主任走了进来，笑着说，"林辰，你的心理素质和应急能力，比很多工作了好几年的医生都强。好好干，前途无量啊。"

　　"谢谢王主任。"林辰说。

　　经过这件事，林辰在科室里的名气一下子大了起来。大家都知道，心内科来了个厉害的实习生。

　　晚上的聚餐，林辰自然成了焦点。大家轮番向他敬酒，林辰来者不拒，喝了不少。

　　聚餐结束的时候，已经是晚上九点多了。林辰喝得有点多，头有些晕。苏小雅看他状态不好，主动提出送他回去。

　　"不用了，我自己能行。"林辰摆摆手说。

　　"行了，别逞强了，"苏小雅扶住他的胳膊，"你都喝成这样了，我怎么放心让你一个人走。"

　　林辰确实有些晕，也就没有再推辞。苏小雅扶着他，慢慢向他租住的小区走去。

　　林辰租的房子在一个老旧的小区里，离医院不远，走路大约二十分钟。两人走到小区门口的时候，突然听到里面传来一阵喧哗声。

　　"让开，快让开！"

　　"有人晕倒了！"

　　林辰一听，酒一下子醒了大半。他挣脱苏小雅的手，快步向里面走去。

　　只见小区的空地上，围着一群人。人群中间，一个中年男子倒在地上，昏迷不醒。

　　"让我看看，我是医生。"林辰挤了进去。

　　他蹲下身，检查了一下男子的情况。呼吸心跳都有，但就是昏迷不醒。再看男子的脸色，潮红发热，嘴唇发紫。

　　"他怎么了？"苏小雅也挤了进来，担心地问。

　　"像是中风。"林辰皱着眉头说，"得赶紧送医院。"

　　"已经打120了，"旁边一个大妈说，"可是救护车最少也要十几分钟才能到。"

　　十几分钟？对于中风病人来说，每一分钟都很宝贵。耽误的时间越长，后遗症就越严重。

　　林辰犹豫了一下。他想起了爷爷教给他的针灸术。爷爷是村里的老中医，从小就教他认穴位、学针灸。只是他学的是西医，从来没在别人面前用过针灸。

　　但现在情况紧急，也顾不了那么多了。

　　"有针吗？"林辰问。

　　"针？什么针？"大妈愣了一下。

　　"缝衣针也行。"林辰说。

　　"有，有，我家就有。"大妈连忙说，然后飞快地跑回家拿了一根缝衣针过来。

　　林辰接过针，用打火机消了消毒，然后对准男子的几个穴位，快速扎了下去。

　　"你...你这是干什么？"旁边的人都吓了一跳。

　　"放心，我是医生，不会有事的。"林辰一边说，一边运针。

　　神奇的事情发生了。只见那男子的手指动了动，然后缓缓睁开了眼睛。

　　"醒了！醒了！"周围的人都惊呼起来。

　　林辰松了一口气，把针拔了出来。

　　"这...这是怎么回事？"男子迷迷糊糊地问。

　　"你刚才晕倒了，"林辰说，"现在感觉怎么样？"

　　"头有点晕，"男子说，"其他的...还好。"

　　就在这时，救护车也到了。医护人员把男子抬上了车，临走前，男子拉着林辰的手说："小伙子，谢谢你，谢谢你救了我一命。"

　　"不用谢，这是我应该做的。"林辰笑了笑说。

　　救护车开走了，围观的人也渐渐散去。苏小雅走到林辰身边，一脸崇拜地说："林辰，你也太厉害了吧！你还会中医针灸啊？"

　　"小时候跟我爷爷学过一点。"林辰谦虚地说。

　　"一点？"苏小雅撇撇嘴，"一点就能把中风的人扎醒？骗谁呢。"

　　林辰笑了笑，没有解释。

　　两人继续往林辰住的楼走去。走到楼梯口的时候，林辰突然停住了脚步。

　　"怎么了？"苏小雅问。

　　"你先回去吧，"林辰说，"我到了。"

　　"哦。"苏小雅有些失望地说，"那...我走了。"

　　"嗯，路上小心。"林辰说。

　　苏小雅点点头，转身走了。走了几步，她又回过头来，对林辰说："林辰，你今天真帅。"

　　说完，她脸一红，飞快地跑了。

　　林辰愣在原地，摸了摸自己的脸，笑了。
        '''.strip()),
        
        ('第二章 神奇的医术', '''
　　第二天，林辰照常去上班。刚到科室，就被王主任叫到了办公室。

　　"林辰，坐。"王主任指了指对面的椅子。

　　林辰坐下，有些疑惑地问："王主任，您找我有事？"

　　"嗯，"王主任点点头，"昨天晚上的事，我听说了。"

　　"什么事？"林辰愣了一下。

　　"就是你在小区里用针灸救了那个中风的人的事，"王主任说，"那人今天早上专门打电话来感谢你，说要不是你，他说不定就瘫痪了。"

　　林辰笑了笑："举手之劳而已。"

　　"举手之劳？"王主任摇摇头，"林辰，你知道吗，中风的黄金抢救时间是4.5小时。你能在救护车到来之前，用针灸让病人苏醒，这可不是一般人能做到的。你跟我说实话，你的针灸术，是跟谁学的？"

　　"跟我爷爷学的，"林辰如实回答，"我爷爷是村里的老中医，我从小就跟着他学医。"

　　"原来如此，"王主任恍然大悟，"怪不得你的基础这么扎实。对了，你爷爷还在吗？"

　　"在的，"林辰说，"他老人家身体还很硬朗。"

　　"有机会一定要见见他老人家，"王主任感慨地说，"现在像你爷爷这样有真本事的老中医，不多了。"

　　顿了顿，王主任又说："对了，林辰，有件事我想跟你商量一下。"

　　"什么事？您说。"林辰说。

　　"是这样的，"王主任说，"我们医院下周要举办一个青年医师技能大赛，我想让你代表我们科室参加。"

　　"我？"林辰愣住了，"王主任，我只是个实习生，参加这种比赛不太合适吧？"

　　"有什么不合适的，"王主任摆摆手，"比赛本来就是给年轻人展示的机会。我看过你的操作，很稳，比很多住院医都强。你就放心去比，拿不拿名次不重要，重要的是锻炼一下。"

　　"那...好吧。"林辰想了想，点头答应了。能参加这样的比赛，对他来说确实是个锻炼的好机会。

　　"好，那就这么定了。"王主任高兴地说，"从今天开始，你上午跟着查房，下午就去技能培训中心训练。我给你找个老师，好好指导指导你。"

　　"谢谢王主任。"林辰说。

　　从王主任办公室出来，苏小雅就凑了过来："怎么样？王主任找你什么事？"

　　"让我参加下周的青年医师技能大赛。"林辰说。

　　"真的？"苏小雅眼睛一亮，"太好了！林辰，你一定要拿个第一名回来！"

　　"哪有那么容易，"林辰笑了笑，"全院那么多优秀的医生，我一个实习生，能进决赛就不错了。"

　　"我相信你，"苏小雅认真地说，"你一定可以的！"

　　看着苏小雅坚定的眼神，林辰心中涌起一股暖流。他笑了笑，说："借你吉言。"

　　接下来的几天，林辰开始了紧张的训练。每天下午，他都泡在技能培训中心，练习各种操作。穿刺、插管、缝合...每一项他都反复练习，直到熟练为止。

　　负责指导他的是医院的技能培训老师张老师。一开始，张老师对这个实习生并不抱太大期望，觉得他能完成基本操作就不错了。但几天训练下来，张老师对林辰刮目相看。

　　"林辰，你这操作水平，比很多工作了两三年的医生都强啊。"张老师赞叹道，"你是怎么练的？"

　　"上学的时候练得多，"林辰谦虚地说，"而且我爷爷从小就让我用绣花针穿米粒，练手的稳定性。"

　　"原来是这样，"张老师点点头，"怪不得你的手这么稳。对了，听说你还会中医针灸？"

　　"略懂一点。"林辰说。

　　"别谦虚，"张老师摆摆手，"王主任都跟我说了，你用一根缝衣针就把中风的人扎醒了。这可不是略懂一点就能做到的。"

　　林辰笑了笑，没有说话。

　　"对了，这次比赛有个中西医结合的项目，"张老师说，"你要是能把针灸用上，说不定能拿高分。"

　　"真的吗？"林辰眼睛一亮。

　　"当然，"张老师说，"比赛规则里说了，鼓励创新。只要能达到治疗效果，用什么方法都行。"

　　"那太好了。"林辰高兴地说。如果能用上中医的方法，他的胜算就更大了。

　　时间过得很快，转眼就到了比赛的日子。

　　比赛在医院的学术报告厅举行，全院共有三十多名青年医生参加。比赛分为初赛和决赛，初赛是笔试加技能操作，取前十名进入决赛。

　　初赛那天，林辰早早地来到了比赛现场。苏小雅也来了，说是给他加油。

　　"林辰，别紧张，你一定可以的！"苏小雅给他打气。

　　"嗯，我不紧张。"林辰笑了笑说。他确实不紧张，从小到大，他经历过的考试无数，从来没有紧张过。

　　笔试开始了。题目并不难，都是一些基础的医学知识，但题量很大，两个小时要做完两百道题。很多考生都在抱怨时间不够，但林辰却做得很从容。他的记忆力很好，这些知识点对他来说都是小菜一碟。

　　笔试结束后，是技能操作考试。内容包括心肺复苏、腹腔穿刺、外科缝合等几项基本操作。

　　林辰抽到的是外科缝合。考官给了他一个模拟伤口，要求他在十分钟内完成缝合。

　　林辰拿起持针器，深吸一口气，开始操作。穿针、进针、出针、打结...每一个动作都标准而流畅。他的手很稳，针脚整齐均匀，间距几乎一模一样。

　　旁边的考官看着看着，眼睛都直了。他当了这么多年考官，还是第一次看到缝得这么漂亮的。

　　"好了。"林辰放下持针器，擦了擦手说。

　　考官看了看时间，才用了不到五分钟。再看看缝合的伤口，简直就是艺术品。

　　"你...你叫什么名字？"考官忍不住问。

　　"林辰。"林辰回答。

　　"林辰...哪个科室的？"考官又问。

　　"心内科的实习生。"林辰说。

　　"实习生？"考官瞪大了眼睛。他还以为是哪个高年资的住院医呢，没想到竟然是个实习生。

　　"真是长江后浪推前浪啊。"考官感慨地说，然后在评分表上打了个满分。

　　初赛结果很快就出来了。林辰以总分第一的成绩进入了决赛。

　　"林辰，你太厉害了！"苏小雅比他还激动，"我就知道你一定可以的！"

　　"运气好而已。"林辰笑着说。

　　"什么运气好，这是实力！"苏小雅不服气地说。

　　决赛在第二天举行，内容是现场救治模拟病人。十名选手抽签决定出场顺序，林辰抽到了最后一个。

　　前面的选手表现都不错，尤其是普外科的一个住院医，操作非常娴熟，得到了评委们的一致好评。

　　终于轮到林辰出场了。

　　"下面上场的是，心内科实习生，林辰。"主持人念道。

　　台下一片窃窃私语。

　　"实习生？实习生也能进决赛？"

　　"不会吧，是不是有什么关系啊？"

　　"看他那样子，估计撑不过五分钟。"

　　听到这些议论，苏小雅气得不行，但林辰却毫不在意。他从容地走到场地中央，向评委们鞠了一躬。

　　"准备好了吗？"主评委问。

　　"准备好了。"林辰点点头。

　　"开始！"

　　随着主评委一声令下，林辰走到模拟病人面前。这是一个高仿真的模拟人，可以模拟各种病情。

　　林辰首先检查了病人的生命体征。血压低，心率快，呼吸急促，意识模糊。

　　"初步判断：失血性休克。"林辰大声说，"立即建立静脉通路，快速补液，配血，准备输血！"

　　他一边说，一边开始操作。消毒、穿刺、置管...动作干净利落，一气呵成。

　　就在这时，模拟病人的病情突然恶化。心率骤降，呼吸停止。

　　"不好，心跳骤停！"林辰立刻开始胸外按压，"肾上腺素一支，静推！准备除颤！"

　　整个抢救过程，林辰都表现得沉着冷静，有条不紊。评委们都暗暗点头，这个实习生的心理素质，确实不一般。

　　经过十分钟的抢救，模拟病人的心跳终于恢复了。但还是昏迷不醒，各项生命体征也不稳定。

　　按照比赛规则，到这里基本就结束了。剩下的就是术后监护，没有太多操作空间。前面的选手都是到这里就结束了。

　　但林辰没有停下来。他从口袋里掏出一盒银针——这是他特意带来的。

　　"他要干什么？"台下的观众都愣住了。

　　"针灸？他不会是想用针灸吧？"

　　"开什么玩笑，这是西医技能比赛，用中医的方法？"

　　评委们也都面面相觑。主评委皱了皱眉头，刚想说话，却看到林辰已经开始下针了。

　　人中、百会、内关、涌泉...林辰的手飞快地在各个穴位上刺入、捻转。他的动作又快又准，每一针都精准地落在穴位上。

　　神奇的事情发生了。只见模拟人——不，这时候大家都忘记了这是个模拟人——只见病人的手指动了动，然后眼睛缓缓睁开了。

　　"醒了！真的醒了！"台下一片惊呼。

　　评委们都站了起来，一脸不可思议地看着林辰。他们当了这么多年医生，还是第一次亲眼见到针灸有这么神奇的效果。

　　林辰松了一口气，把针拔了出来。然后转向评委，鞠了一躬："报告评委，抢救完毕。"

　　现场鸦雀无声。过了好一会儿，主评委才回过神来，激动地说："好！好！好！真是英雄出少年啊！"

　　全场爆发出雷鸣般的掌声。

　　苏小雅在台下跳了起来，一边鼓掌一边喊："林辰，你太棒了！"

　　比赛结果毫无悬念，林辰获得了第一名。

　　站在领奖台上，捧着奖杯，林辰的心情也很激动。他知道，这只是一个开始。他的从医生涯，才刚刚起步。

　　他暗暗发誓，一定要成为一名最好的医生，救更多的人。
        '''.strip())
    ]
    
    for i, (title, content) in enumerate(chapters_2):
        word_count = len(content.replace(' ', '').replace('\n', ''))
        db.execute('''
            INSERT INTO chapters (book_id, chapter_number, title, content, word_count)
            VALUES (?, ?, ?, ?, ?)
        ''', (book2_id, i + 1, title, content, word_count))
    
    db.execute('''
        UPDATE books SET chapter_count = (SELECT COUNT(*) FROM chapters WHERE book_id = ?),
        word_count = (SELECT SUM(word_count) FROM chapters WHERE book_id = ?)
        WHERE id = ?
    ''', (book2_id, book2_id, book2_id))
    
    # 示例小说 3: 科幻小说
    book3_id = db.execute('''
        INSERT INTO books (title, author, cover, description, category, status)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        '星际迷航：新纪元',
        '星空漫步者',
        '🚀',
        '公元3025年，人类已经走出太阳系，在银河系中建立了无数殖民地。年轻的宇航员林风，驾驶着最新型的探索舰，踏上了未知星域的冒险之旅。',
        '科幻未来',
        '连载中'
    )).lastrowid
    
    chapters_3 = [
        ('第一章 启航', '''
　　公元3025年，地球联邦首都星——新北京。

　　巨大的太空港漂浮在近地轨道上，宛如一座钢铁铸就的城市。数以千计的飞船在这里起起落落，构成了一幅繁忙而壮观的画面。

　　在太空港的最深处，停泊着一艘崭新的星舰。这艘星舰通体银白色，线条流畅优美，舰首刻着两个大字——"探索号"。

　　这是地球联邦最新研制的探索舰，配备了最先进的曲率引擎，可以进行超光速航行。它的任务，是前往银河系边缘的未知星域，寻找新的宜居星球。

　　此时，探索号的舰桥内，一群身着制服的军人正在做最后的准备工作。

　　"舰长，所有系统检查完毕，一切正常。"副舰长陈雪向舰长林风报告。

　　陈雪是一位年轻的女军官，长得很漂亮，但眉宇间却带着一股英气。她是联邦军事学院的高材生，也是林风的老搭档了。

　　"好。"林风点点头。他站在舷窗前，看着窗外的星空，眼中闪烁着兴奋的光芒。

　　林风今年二十八岁，是联邦历史上最年轻的星舰舰长。他出身于军人世家，从小就立志要当一名宇航员。凭着过人的天赋和不懈的努力，他一步步走到了今天的位置。

　　这次探索未知星域的任务，危险与机遇并存。很多人都劝他不要去，但林风毫不犹豫地接下了这个任务。因为他知道，这是他的使命。

　　"舰长，联邦总部来电，问我们准备好了没有。"通讯官报告。

　　"回复总部，探索号全体官兵已经准备完毕，随时可以启航。"林风说。

　　"是！"

　　林风转过身来，看着舰桥上的船员们，沉声说："各位，这次任务的重要性，我想不用我多说了。人类的未来，就在我们手中。我知道，前面的路充满了未知和危险，但我相信，我们一定能够完成任务，满载而归！"

　　"保证完成任务！"全体船员齐声回答，声音铿锵有力。

　　"好！"林风满意地点点头，"出发！"

　　"是！"

　　随着林风一声令下，探索号缓缓驶离了太空港。越来越快，越来越快，很快就变成了一个小点，消失在茫茫宇宙中。

　　"曲率引擎启动倒计时：十、九、八、七、六、五、四、三、二、一！"

　　"启动！"

　　随着曲率引擎的启动，探索号周围的空间开始扭曲。下一秒，飞船就消失在了原地，进入了超光速航行状态。

　　舰桥上，所有人都松了一口气。曲率引擎启动成功，意味着他们的旅程正式开始了。

　　"舰长，我们已经进入曲率航行状态。预计将在七十二小时后到达目标星域。"陈雪说。

　　"嗯，"林风点点头，"让大家轮流休息，保持体力。到了地方，有的忙了。"

　　"是。"陈雪答应一声，转身去安排了。

　　林风走到舷窗前，看着窗外流光溢彩的景象。在曲率航行中，窗外的星星都被拉成了一条条光线，看起来如梦似幻。

　　林风从小就喜欢看星星。小时候，他经常坐在院子里，仰望星空，想象着星星上面是什么样子。那时候，他就下定决心，长大后一定要去看看那些星星。

　　现在，他的梦想实现了。他不仅走出了地球，走出了太阳系，还要去探索银河系的边缘。

　　"在想什么呢？"陈雪走过来，轻声问。

　　"没什么，"林风笑了笑，"就是想起了小时候的事。"

　　"小时候的事？"陈雪好奇地问，"什么事？"

　　"我小时候，经常坐在院子里看星星，"林风说，"那时候我就在想，星星上面是什么样子的。没想到，现在我真的来到了星星之间。"

　　陈雪笑了："我也是。我小时候的梦想，就是当一名宇航员，去看看外面的世界。现在想想，还挺不可思议的。"

　　"是啊，"林风感慨地说，"人类真是一种神奇的生物。从树上下来，到走出地球，只用了几百万年。谁知道再过几百万年，人类会变成什么样子呢。"

　　"一定会更好的。"陈雪说。

　　林风笑了笑，没有说话。他希望如此，但他也知道，宇宙中充满了未知和危险。人类的未来，究竟会怎样，谁也说不准。

　　"好了，我去休息一下，"林风说，"这里交给你了。有什么事，随时叫我。"

　　"好的，你去吧。"陈雪点点头。

　　林风回到自己的舱室，躺在床上，却怎么也睡不着。他太兴奋了，一想到即将面对的未知世界，他的心就怦怦直跳。

　　不知过了多久，他才迷迷糊糊地睡了过去。

　　在梦中，他看到了无数奇异的星球，看到了各种各样的外星生物，看到了人类在银河系中繁衍生息...

　　"舰长！舰长！"

　　突然，一阵急促的呼喊声将林风从梦中惊醒。

　　"怎么了？"林风一骨碌爬起来，问道。

　　"舰长，不好了！"通讯员的声音从通讯器里传来，"我们...我们遇到了不明飞船！"

　　"什么？"林风一惊，连忙穿好衣服，向舰桥跑去。

　　来到舰桥，只见所有人都一脸紧张地看着雷达屏幕。屏幕上，一个巨大的光点正在快速向他们靠近。

　　"怎么回事？"林风沉声问。

　　"舰长，"雷达官报告，"十分钟前，我们的雷达探测到一艘不明飞船。它的速度很快，正在向我们靠近。根据外形判断，不是我们已知的任何一种飞船。"

　　"外星飞船？"陈雪皱着眉头说。

　　"很有可能。"雷达官点点头。

　　所有人都紧张起来。人类虽然已经走出太阳系几百年了，但还从来没有遇到过真正的外星文明。现在，他们竟然在半路上遇到了不明飞船，这怎能不让人紧张。

　　"舰长，我们该怎么办？"陈雪问。

　　林风沉吟了片刻，然后说："先减速，退出曲率航行。看看对方是什么意图。"

　　"是！"

　　随着林风的命令，探索号缓缓退出了曲率航行状态，停在了宇宙空间中。

　　那艘不明飞船也跟着停了下来，就在探索号前方不远处。

　　"能看清楚它的样子吗？"林风问。

　　"可以，"雷达官点点头，"正在把图像传到主屏幕上。"

　　主屏幕上出现了那艘飞船的图像。那是一艘巨大的碟形飞船，通体暗金色，表面刻满了奇异的花纹。它的体积比探索号大了好几倍，静静地悬浮在那里，散发着一股神秘而强大的气息。

　　"天哪..."陈雪忍不住惊叹道，"这...这就是外星飞船吗？"

　　所有人都被震撼了。他们虽然想象过外星飞船的样子，但真正见到的时候，还是被深深地震撼了。

　　"舰长，对方发来了信号。"通讯官突然说。

　　"什么信号？"林风问。

　　"不知道，"通讯官摇摇头，"是一种我们从未见过的编码方式。我们的计算机正在破解，但需要时间。"

　　"需要多久？"林风问。

　　"最少也要几个小时。"通讯官说。

　　林风皱了皱眉头。几个小时，太长了。谁知道这几个小时里会发生什么事。

　　就在这时，那艘外星飞船突然动了。它缓缓向探索号驶来。

　　"不好，它过来了！"雷达官惊呼。

　　"全体戒备！"林风沉声说，"武器系统待命！"

　　"是！"

　　所有人都紧张起来。武器官的手放在了发射按钮上，只等林风一声令下。

　　外星飞船越来越近，越来越近。所有人的心都提到了嗓子眼。

　　就在外星飞船距离探索号只有不到一百公里的时候，它突然停了下来。

　　然后，一道光束从外星飞船上射出，照在了探索号的舰桥上。

　　"不好，是武器吗？"陈雪紧张地问。

　　"不是，"武器官摇摇头，"没有能量反应。这束光...好像是某种通讯信号。"

　　"通讯信号？"林风愣了一下。

　　就在这时，舰桥中央突然出现了一个全息投影。投影中，是一个人形生物。它的外形和人类很像，也是两只眼睛一个鼻子一张嘴，但皮肤是淡蓝色的，耳朵尖尖的，比人类的耳朵大很多。

　　所有人都愣住了。这就是...外星人？

　　那个外星人看了看四周，然后开口说话了。它说的不是人类的语言，但奇怪的是，所有人都能听懂它的意思。

　　"地球来的朋友，你们好。我是银河联邦的使者，欢迎你们来到银河系。"
        '''.strip())
    ]
    
    for i, (title, content) in enumerate(chapters_3):
        word_count = len(content.replace(' ', '').replace('\n', ''))
        db.execute('''
            INSERT INTO chapters (book_id, chapter_number, title, content, word_count)
            VALUES (?, ?, ?, ?, ?)
        ''', (book3_id, i + 1, title, content, word_count))
    
    db.execute('''
        UPDATE books SET chapter_count = (SELECT COUNT(*) FROM chapters WHERE book_id = ?),
        word_count = (SELECT SUM(word_count) FROM chapters WHERE book_id = ?)
        WHERE id = ?
    ''', (book3_id, book3_id, book3_id))
    
    db.commit()
    db.close()
    print('示例数据已添加')


# ==================== 本地书籍导入 ====================

COVER_COLORS = [
    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
    'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
    'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
]


def read_text_content(filepath):
    """尝试多种编码读取文本文件"""
    encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030', 'utf-16']
    for enc in encodings:
        try:
            with open(filepath, 'r', encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, UnicodeError):
            continue
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read()


def parse_novel_content(content, default_title='未知书名'):
    """
    解析小说内容，提取书名、作者、简介、章节
    """
    lines = content.split('\n')
    
    # 提取书名和作者
    title = default_title
    author = '未知作者'
    description = ''
    
    # 从前20行查找书名和作者
    for line in lines[:20]:
        stripped = line.strip()
        if not stripped:
            continue
        # 匹配 《书名》 作者：xxx 格式
        m = re.match(r'[《【](.+?)[》】]\s*作者[：:]\s*(.+)', stripped)
        if m:
            title = m.group(1)
            author = m.group(2)
            break
        # 单独作者行
        m2 = re.match(r'作者[：:]\s*(.+)', stripped)
        if m2 and author == '未知作者':
            author = m2.group(1)
        # 书名行（开头且包含书名号）
        if title == default_title:
            m3 = re.match(r'[《【](.+?)[》】]', stripped)
            if m3 and len(m3.group(1)) < 30:
                title = m3.group(1)
    
    # 提取简介
    desc_start = -1
    desc_end = -1
    for i, line in enumerate(lines[:50]):
        if '内容简介' in line or '简介' in line or '作品简介' in line:
            desc_start = i + 1
        if desc_start > 0 and re.match(r'^第[一二三四五六七八九十百千\d]+[章节回卷]', line.strip()):
            desc_end = i
            break
    
    if desc_start > 0 and desc_end > desc_start:
        desc_lines = []
        for line in lines[desc_start:desc_end]:
            stripped = line.strip()
            if stripped and not re.match(r'^[-=*]+$', stripped) and len(stripped) > 1:
                desc_lines.append(stripped)
        description = '\n'.join(desc_lines)[:500]
    
    # 提取章节
    chapters = []
    current_title = None
    current_content = []
    
    # 支持多种章节格式
    chapter_patterns = [
        re.compile(r'^第[一二三四五六七八九十百千\d]+[章节回卷]\s*(.+)$'),
        re.compile(r'^第[一二三四五六七八九十百千\d]+[章节回卷]$'),
        re.compile(r'^Chapter\s+\d+', re.IGNORECASE),
        re.compile(r'^第\s+\d+\s+[章节回卷]'),
    ]
    
    def is_chapter_line(line):
        stripped = line.strip()
        for p in chapter_patterns:
            if p.match(stripped):
                return True
        return False
    
    def get_chapter_title(line):
        stripped = line.strip()
        m = chapter_patterns[0].match(stripped)
        if m:
            subtitle = m.group(1).strip()
            return subtitle if subtitle else stripped
        return stripped
    
    for line in lines:
        if is_chapter_line(line):
            # 保存上一章
            if current_title is not None:
                chapter_content = '\n'.join(current_content).strip()
                word_count = len(chapter_content.replace('\n', '').replace(' ', '').replace('\u3000', ''))
                if word_count > 50:  # 过滤空章节
                    chapters.append({
                        'title': current_title,
                        'content': chapter_content,
                        'word_count': word_count
                    })
            current_title = get_chapter_title(line)
            current_content = []
        elif current_title is not None:
            # 跳过分隔线和卷标题
            stripped = line.strip()
            if re.match(r'^[-=*_]{3,}$', stripped):
                continue
            if re.match(r'^第.+卷', stripped) and len(stripped) < 20:
                continue
            current_content.append(line)
    
    # 保存最后一章
    if current_title is not None:
        chapter_content = '\n'.join(current_content).strip()
        word_count = len(chapter_content.replace('\n', '').replace(' ', '').replace('\u3000', ''))
        if word_count > 50:
            chapters.append({
                'title': current_title,
                'content': chapter_content,
                'word_count': word_count
            })
    
    # 如果没有解析到章节，将整个内容作为一章
    if len(chapters) == 0:
        content_clean = content.strip()
        chapters.append({
            'title': '正文',
            'content': content_clean,
            'word_count': len(content_clean.replace('\n', '').replace(' ', '').replace('\u3000', ''))
        })
    
    # 分类判断
    category = '其他'
    category_keywords = {
        '都市': ['美女', '总裁', '校花', '都市', '职场', '重生', '穿越'],
        '玄幻': ['修仙', '修真', '玄幻', '魔法', '斗气', '分身', '机器人'],
        '武侠': ['江湖', '剑客', '武侠', '武功'],
        '科幻': ['星际', '外星', '飞船', '银河', '未来'],
    }
    all_text = title + description
    for cat, keywords in category_keywords.items():
        for kw in keywords:
            if kw in all_text:
                category = cat
                break
        if category != '其他':
            break
    
    total_words = sum(c['word_count'] for c in chapters)
    
    return {
        'title': title,
        'author': author,
        'description': description,
        'chapters': chapters,
        'chapter_count': len(chapters),
        'word_count': total_words,
        'category': category
    }


@app.route('/api/import', methods=['POST'])
def api_import_book():
    """导入本地txt小说"""
    try:
        if 'file' not in request.files:
            return jsonify({'code': 1, 'msg': '请选择要上传的文件'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'code': 1, 'msg': '请选择文件'})
        
        if not file.filename.lower().endswith('.txt'):
            return jsonify({'code': 1, 'msg': '目前只支持TXT格式的小说'})
        
        # 保存文件到Novel目录
        filename = file.filename
        # 处理中文文件名
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(save_path)
        
        # 读取并解析
        content = read_text_content(save_path)
        default_title = os.path.splitext(filename)[0]
        book_info = parse_novel_content(content, default_title)
        
        if book_info['chapter_count'] == 0:
            return jsonify({'code': 1, 'msg': '未能解析到任何章节，请检查文件格式'})
        
        # 检查是否已存在同名书籍
        db = get_db()
        existing = db.execute(
            'SELECT id FROM books WHERE title = ?',
            (book_info['title'],)
        ).fetchone()
        
        if existing:
            return jsonify({'code': 2, 'msg': f'《{book_info["title"]}》已在书架中', 'book_id': existing['id']})
        
        # 选择封面颜色
        import random
        cover = random.choice(COVER_COLORS)
        
        # 插入书籍
        cursor = db.execute('''
            INSERT INTO books (title, author, cover, description, category, word_count, chapter_count, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            book_info['title'],
            book_info['author'],
            cover,
            book_info['description'],
            book_info['category'],
            book_info['word_count'],
            book_info['chapter_count'],
            '连载中'
        ))
        
        book_id = cursor.lastrowid
        
        # 插入章节
        for i, chapter in enumerate(book_info['chapters'], 1):
            db.execute('''
                INSERT INTO chapters (book_id, chapter_number, title, content, word_count)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                book_id,
                i,
                chapter['title'],
                chapter['content'],
                chapter['word_count']
            ))
        
        db.commit()
        
        return jsonify({
            'code': 0,
            'msg': '导入成功',
            'data': {
                'book_id': book_id,
                'title': book_info['title'],
                'author': book_info['author'],
                'chapter_count': book_info['chapter_count'],
                'word_count': book_info['word_count']
            }
        })
        
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'导入失败: {str(e)}'})


# ==================== 启动入口 ====================

if __name__ == '__main__':
    # 初始化数据库
    init_db()
    # 添加示例数据
    seed_sample_data()
    # 启动服务
    print('=' * 50)
    print('小说阅读器启动成功！')
    print('访问地址: http://localhost:5001')
    print('=' * 50)
    app.run(host='0.0.0.0', port=5001, debug=True)
