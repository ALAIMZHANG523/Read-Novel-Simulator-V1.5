// 小说阅读器 Service Worker - 完全离线版本
const CACHE_NAME = 'novel-reader-v2';
const OFFLINE_URL = '/index.html';

// 需要缓存的核心资源
const CORE_ASSETS = [
  '/index.html',
  '/read.html',
  '/catalog.html',
  '/bookmarks.html',
  '/profile.html',
  '/static/css/style.css',
  '/static/js/app.js',
  '/static/icon/书架-L.png',
  '/static/icon/icon-72x72.png',
  '/static/icon/icon-96x96.png',
  '/static/icon/icon-128x128.png',
  '/static/icon/icon-144x144.png',
  '/static/icon/icon-152x152.png',
  '/static/icon/icon-192x192.png',
  '/static/icon/icon-384x384.png',
  '/static/icon/icon-512x512.png',
  '/static/manifest.json'
];

// 安装阶段 - 缓存核心资源
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(CORE_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

// 激活阶段 - 清理旧缓存
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// 请求拦截 - 缓存优先，完全离线
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // 后台更新缓存
        fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, networkResponse.clone());
            });
          }
        }).catch(() => {});
        return cachedResponse;
      }
      
      // 没有缓存，走网络
      return fetch(event.request).then((response) => {
        if (!response || response.status !== 200) {
          return response;
        }
        
        // 缓存新资源
        const responseToCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });
        
        return response;
      }).catch(() => {
        // 网络失败，显示离线页面
        if (event.request.destination === 'document') {
          return caches.match(OFFLINE_URL);
        }
      });
    })
  );
});
