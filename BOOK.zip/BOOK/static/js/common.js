// 小说阅读器 - 公共工具函数

// Toast 提示
function showToast(message, duration = 2000) {
    // 检查是否已有toast
    let toast = document.querySelector('.toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    
    toast.textContent = message;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, duration);
}

// 格式化字数
function formatWordCount(count) {
    if (count < 10000) {
        return count + '字';
    } else if (count < 100000000) {
        return (count / 10000).toFixed(1) + '万字';
    } else {
        return (count / 100000000).toFixed(1) + '亿字';
    }
}

// 格式化时间
function formatTime(timeStr) {
    if (!timeStr) return '暂无';
    
    const now = new Date();
    const time = new Date(timeStr.replace(/-/g, '/'));
    const diff = now - time;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return '刚刚';
    if (minutes < 60) return minutes + '分钟前';
    if (hours < 24) return hours + '小时前';
    if (days < 7) return days + '天前';
    
    return timeStr.split(' ')[0];
}

// 本地存储工具
const Storage = {
    get(key, defaultValue = null) {
        try {
            const value = localStorage.getItem(key);
            return value ? JSON.parse(value) : defaultValue;
        } catch (e) {
            return defaultValue;
        }
    },
    
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            return false;
        }
    },
    
    remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (e) {
            return false;
        }
    }
};

// 阅读设置
const ReaderSettings = {
    getFontSize() {
        return Storage.get('reader_font_size', 18);
    },
    
    setFontSize(size) {
        size = Math.max(14, Math.min(28, size));
        Storage.set('reader_font_size', size);
        return size;
    },
    
    getTheme() {
        return Storage.get('reader_theme', 'light');
    },
    
    setTheme(theme) {
        Storage.set('reader_theme', theme);
    },
    
    getScrollPosition(bookId) {
        const positions = Storage.get('reader_scroll_positions', {});
        return positions[bookId] || 0;
    },
    
    setScrollPosition(bookId, position) {
        const positions = Storage.get('reader_scroll_positions', {});
        positions[bookId] = position;
        Storage.set('reader_scroll_positions', positions);
    }
};

// API 请求封装
const API = {
    async get(url) {
        try {
            const response = await fetch(url);
            const data = await response.json();
            return data;
        } catch (e) {
            console.error('API请求失败:', e);
            return { code: -1, msg: '网络错误' };
        }
    },
    
    async post(url, data) {
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            return result;
        } catch (e) {
            console.error('API请求失败:', e);
            return { code: -1, msg: '网络错误' };
        }
    },
    
    async del(url) {
        try {
            const response = await fetch(url, {
                method: 'DELETE'
            });
            const data = await response.json();
            return data;
        } catch (e) {
            console.error('API请求失败:', e);
            return { code: -1, msg: '网络错误' };
        }
    }
};

// 页面加载完成后的通用初始化
document.addEventListener('DOMContentLoaded', function() {
    // 禁止双指缩放
    document.addEventListener('gesturestart', function(e) {
        e.preventDefault();
    });
    
    // 禁止双击放大
    let lastTouchEnd = 0;
    document.addEventListener('touchend', function(e) {
        const now = Date.now();
        if (now - lastTouchEnd <= 300) {
            e.preventDefault();
        }
        lastTouchEnd = now;
    }, false);
});
