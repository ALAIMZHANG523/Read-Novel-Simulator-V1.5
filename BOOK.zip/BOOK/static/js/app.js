/**
 * 小说阅读器 - 纯前端版本
 * 使用 IndexedDB 存储所有数据，完全离线运行
 */

const DB_NAME = 'NovelReaderDB';
const DB_VERSION = 1;

// 封面颜色
const COVER_COLORS = [
    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
    'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
    'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
];

let db = null;

// 打开数据库
function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
            db = request.result;
            resolve(db);
        };
        
        request.onupgradeneeded = (event) => {
            const database = event.target.result;
            
            // 书籍表
            if (!database.objectStoreNames.contains('books')) {
                const bookStore = database.createObjectStore('books', { keyPath: 'id', autoIncrement: true });
                bookStore.createIndex('title', 'title', { unique: false });
                bookStore.createIndex('last_read_time', 'last_read_time', { unique: false });
            }
            
            // 章节表
            if (!database.objectStoreNames.contains('chapters')) {
                const chapterStore = database.createObjectStore('chapters', { keyPath: 'id', autoIncrement: true });
                chapterStore.createIndex('book_id', 'book_id', { unique: false });
                chapterStore.createIndex('book_chapter', ['book_id', 'chapter_number'], { unique: true });
            }
            
            // 阅读进度表
            if (!database.objectStoreNames.contains('progress')) {
                const progressStore = database.createObjectStore('progress', { keyPath: 'book_id' });
            }
            
            // 书签表
            if (!database.objectStoreNames.contains('bookmarks')) {
                const bookmarkStore = database.createObjectStore('bookmarks', { keyPath: 'id', autoIncrement: true });
                bookmarkStore.createIndex('book_id', 'book_id', { unique: false });
            }
        };
    });
}

// 数据库操作封装
function dbAdd(storeName, data) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.add(data);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

function dbPut(storeName, data) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.put(data);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

function dbGet(storeName, key) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.get(key);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

function dbGetAll(storeName, indexName = null, indexValue = null) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        let request;
        if (indexName && indexValue !== null) {
            const index = store.index(indexName);
            request = index.getAll(indexValue);
        } else {
            request = store.getAll();
        }
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

function dbDelete(storeName, key) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.delete(key);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
}

function dbClear(storeName) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
}

// ========== 小说解析 ==========

function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            // 尝试检测编码，默认用UTF-8，失败用GBK
            const content = e.target.result;
            resolve(content);
        };
        reader.onerror = () => reject(reader.error);
        // 先用GBK解码尝试（大多数中文TXT是GBK）
        reader.readAsText(file, 'GBK');
    });
}

function parseNovelContent(content, defaultTitle = '未知书名') {
    const lines = content.split('\n');
    
    let title = defaultTitle;
    let author = '未知作者';
    let description = '';
    
    // 提取书名和作者
    for (let i = 0; i < Math.min(lines.length, 30); i++) {
        const stripped = lines[i].trim();
        if (!stripped) continue;
        
        const m = stripped.match(/[《【](.+?)[》】]\s*作者[：:]\s*(.+)/);
        if (m) {
            title = m[1];
            author = m[2];
            break;
        }
        const m2 = stripped.match(/作者[：:]\s*(.+)/);
        if (m2 && author === '未知作者') {
            author = m2[1];
        }
        if (title === defaultTitle) {
            const m3 = stripped.match(/[《【](.+?)[》】]/);
            if (m3 && m3[1].length < 30) {
                title = m3[1];
            }
        }
    }
    
    // 提取简介
    let descStart = -1;
    let descEnd = -1;
    for (let i = 0; i < Math.min(lines.length, 60); i++) {
        if (lines[i].includes('内容简介') || lines[i].includes('简介') || lines[i].includes('作品简介')) {
            descStart = i + 1;
        }
        if (descStart > 0 && /^第[一二三四五六七八九十百千\d]+[章节回卷]/.test(lines[i].trim())) {
            descEnd = i;
            break;
        }
    }
    
    if (descStart > 0 && descEnd > descStart) {
        const descLines = [];
        for (let i = descStart; i < descEnd; i++) {
            const stripped = lines[i].trim();
            if (stripped && !/^[-=*]+$/.test(stripped) && stripped.length > 1) {
                descLines.push(stripped);
            }
        }
        description = descLines.join('\n').substring(0, 500);
    }
    
    // 提取章节
    const chapters = [];
    let currentTitle = null;
    let currentContent = [];
    
    const chapterPatterns = [
        /^第[一二三四五六七八九十百千\d]+[章节回卷]\s*(.+)$/,
        /^第[一二三四五六七八九十百千\d]+[章节回卷]$/,
        /^Chapter\s+\d+/i,
        /^第\s+\d+\s+[章节回卷]/,
    ];
    
    function isChapterLine(line) {
        const stripped = line.trim();
        for (const p of chapterPatterns) {
            if (p.test(stripped)) return true;
        }
        return false;
    }
    
    function getChapterTitle(line) {
        const stripped = line.trim();
        const m = stripped.match(chapterPatterns[0]);
        if (m) {
            const subtitle = m[1].trim();
            return subtitle || stripped;
        }
        return stripped;
    }
    
    for (const line of lines) {
        if (isChapterLine(line)) {
            if (currentTitle !== null) {
                const chapterContent = currentContent.join('\n').trim();
                const wordCount = chapterContent.replace(/[\n\s\u3000]/g, '').length;
                if (wordCount > 50) {
                    chapters.push({
                        title: currentTitle,
                        content: chapterContent,
                        word_count: wordCount
                    });
                }
            }
            currentTitle = getChapterTitle(line);
            currentContent = [];
        } else if (currentTitle !== null) {
            const stripped = line.trim();
            if (/^[-=*_]{3,}$/.test(stripped)) continue;
            if (/^第.+卷/.test(stripped) && stripped.length < 20) continue;
            currentContent.push(line);
        }
    }
    
    if (currentTitle !== null) {
        const chapterContent = currentContent.join('\n').trim();
        const wordCount = chapterContent.replace(/[\n\s\u3000]/g, '').length;
        if (wordCount > 50) {
            chapters.push({
                title: currentTitle,
                content: chapterContent,
                word_count: wordCount
            });
        }
    }
    
    if (chapters.length === 0) {
        const contentClean = content.trim();
        chapters.push({
            title: '正文',
            content: contentClean,
            word_count: contentClean.replace(/[\n\s\u3000]/g, '').length
        });
    }
    
    let category = '其他';
    const categoryKeywords = {
        '都市': ['美女', '总裁', '校花', '都市', '职场', '重生', '穿越'],
        '玄幻': ['修仙', '修真', '玄幻', '魔法', '斗气', '分身', '机器人'],
        '武侠': ['江湖', '剑客', '武侠', '武功'],
        '科幻': ['星际', '外星', '飞船', '银河', '未来'],
    };
    const allText = title + description;
    for (const [cat, keywords] of Object.entries(categoryKeywords)) {
        for (const kw of keywords) {
            if (allText.includes(kw)) {
                category = cat;
                break;
            }
        }
        if (category !== '其他') break;
    }
    
    const totalWords = chapters.reduce((sum, c) => sum + c.word_count, 0);
    
    return {
        title,
        author,
        description,
        chapters,
        chapter_count: chapters.length,
        word_count: totalWords,
        category
    };
}

// ========== 书籍管理 ==========

async function importBook(file) {
    const content = await readFileAsText(file);
    const defaultTitle = file.name.replace(/\.[^.]+$/, '');
    const bookInfo = parseNovelContent(content, defaultTitle);
    
    if (bookInfo.chapter_count === 0) {
        throw new Error('未能解析到任何章节');
    }
    
    // 检查重名
    const existingBooks = await dbGetAll('books');
    const existing = existingBooks.find(b => b.title === bookInfo.title);
    if (existing) {
        return { code: 2, msg: `《${bookInfo.title}》已在书架中`, book_id: existing.id };
    }
    
    const cover = COVER_COLORS[Math.floor(Math.random() * COVER_COLORS.length)];
    
    const bookId = await dbAdd('books', {
        title: bookInfo.title,
        author: bookInfo.author,
        cover,
        description: bookInfo.description,
        category: bookInfo.category,
        word_count: bookInfo.word_count,
        chapter_count: bookInfo.chapter_count,
        status: '连载中',
        created_time: Date.now(),
        last_read_time: Date.now(),
        update_time: Date.now()
    });
    
    // 插入章节
    for (let i = 0; i < bookInfo.chapters.length; i++) {
        const chapter = bookInfo.chapters[i];
        await dbAdd('chapters', {
            book_id: bookId,
            chapter_number: i + 1,
            title: chapter.title,
            content: chapter.content,
            word_count: chapter.word_count
        });
    }
    
    return {
        code: 0,
        msg: '导入成功',
        data: {
            book_id: bookId,
            title: bookInfo.title,
            author: bookInfo.author,
            chapter_count: bookInfo.chapter_count,
            word_count: bookInfo.word_count
        }
    };
}

async function getBooks() {
    const books = await dbGetAll('books');
    // 按最后阅读时间倒序
    return books.sort((a, b) => (b.last_read_time || 0) - (a.last_read_time || 0));
}

async function getBook(bookId) {
    return await dbGet('books', bookId);
}

async function deleteBook(bookId) {
    // 删除书籍
    await dbDelete('books', bookId);
    // 删除章节
    const chapters = await dbGetAll('chapters', 'book_id', bookId);
    for (const ch of chapters) {
        await dbDelete('chapters', ch.id);
    }
    // 删除进度
    await dbDelete('progress', bookId);
    // 删除书签
    const bookmarks = await dbGetAll('bookmarks', 'book_id', bookId);
    for (const bm of bookmarks) {
        await dbDelete('bookmarks', bm.id);
    }
}

async function getChapters(bookId) {
    const chapters = await dbGetAll('chapters', 'book_id', bookId);
    return chapters.sort((a, b) => a.chapter_number - b.chapter_number);
}

async function getChapter(bookId, chapterNumber) {
    const chapters = await dbGetAll('chapters', 'book_id', bookId);
    return chapters.find(c => c.chapter_number === chapterNumber);
}

async function getChapterCount(bookId) {
    const chapters = await dbGetAll('chapters', 'book_id', bookId);
    return chapters.length;
}

// ========== 阅读进度 ==========

async function saveProgress(bookId, chapterNumber, scrollPosition) {
    const progress = {
        book_id: bookId,
        chapter_number: chapterNumber,
        scroll_position: scrollPosition,
        read_time: Date.now()
    };
    await dbPut('progress', progress);
    
    // 更新书籍最后阅读时间
    const book = await dbGet('books', bookId);
    if (book) {
        book.last_read_time = Date.now();
        await dbPut('books', book);
    }
}

async function getProgress(bookId) {
    return await dbGet('progress', bookId);
}

// ========== 书签管理 ==========

async function addBookmark(bookId, chapterNumber, position, excerpt) {
    return await dbAdd('bookmarks', {
        book_id: bookId,
        chapter_number: chapterNumber,
        position,
        excerpt: excerpt || '',
        created_time: Date.now()
    });
}

async function getBookmarks(bookId = null) {
    if (bookId) {
        return await dbGetAll('bookmarks', 'book_id', bookId);
    }
    const bookmarks = await dbGetAll('bookmarks');
    // 关联书籍信息
    const books = await dbGetAll('books');
    const bookMap = {};
    books.forEach(b => bookMap[b.id] = b);
    return bookmarks.map(bm => ({
        ...bm,
        book_title: bookMap[bm.book_id]?.title || '未知书籍'
    })).sort((a, b) => b.created_time - a.created_time);
}

async function deleteBookmark(bookmarkId) {
    await dbDelete('bookmarks', bookmarkId);
}

// ========== 工具函数 ==========

function formatWordCount(count) {
    if (count >= 10000) {
        return (count / 10000).toFixed(1) + '万字';
    }
    return count + '字';
}

function formatTime(timestamp) {
    if (!timestamp) return '';
    const now = Date.now();
    const diff = now - timestamp;
    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    
    if (diff < minute) return '刚刚';
    if (diff < hour) return Math.floor(diff / minute) + '分钟前';
    if (diff < day) return Math.floor(diff / hour) + '小时前';
    if (diff < 7 * day) return Math.floor(diff / day) + '天前';
    
    const date = new Date(timestamp);
    return `${date.getMonth() + 1}月${date.getDate()}日`;
}

function showToast(message) {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0,0,0,0.75);
        color: #fff;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        z-index: 10000;
        pointer-events: none;
        transition: opacity 0.3s;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 2000);
}

// 页面切换
function navigateTo(url) {
    window.location.href = url;
}

function switchTab(tab) {
    const urls = {
        'shelf': '/index.html',
        'bookmarks': '/bookmarks.html',
        'profile': '/profile.html'
    };
    if (urls[tab]) {
        window.location.href = urls[tab];
    }
}

// 初始化数据库
async function initDB() {
    await openDB();
}

// 从URL获取参数
function getUrlParam(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name);
}

// 本地设置
function getSetting(key, defaultValue) {
    try {
        const val = localStorage.getItem('novel_' + key);
        return val !== null ? JSON.parse(val) : defaultValue;
    } catch {
        return defaultValue;
    }
}

function setSetting(key, value) {
    localStorage.setItem('novel_' + key, JSON.stringify(value));
}
