# -*- coding: utf-8 -*-
"""
小说阅读器 - 本地服务器启动脚本
使用方法: python 启动服务器.py
不需要安装Flask，使用Python内置HTTP服务器
"""
import http.server
import socketserver
import os
import socket

PORT = 5001

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """自定义MIME类型处理器"""
    
    def end_headers(self):
        # 添加CORS头和Service Worker支持
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Service-Worker-Allowed', '/')
        super().end_headers()
    
    def guess_type(self, path):
        mimetype, encoding = super().guess_type(path)
        
        # 修复json和js的MIME类型
        if path.endswith('.json'):
            return 'application/json'
        if path.endswith('.js'):
            return 'application/javascript'
        if path.endswith('.png'):
            return 'image/png'
        if path.endswith('.svg'):
            return 'image/svg+xml'
        if path.endswith('.css'):
            return 'text/css'
        if path.endswith('.html'):
            return 'text/html; charset=utf-8'
        
        return mimetype

def get_local_ip():
    """获取本机局域网IP"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '127.0.0.1'

if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    Handler = MyHTTPRequestHandler
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        local_ip = get_local_ip()
        print("=" * 50)
        print("   小说阅读器 - 本地服务器已启动")
        print("=" * 50)
        print()
        print("   本机访问: http://localhost:{}".format(PORT))
        print("   手机访问: http://{}:{}  (同一WiFi)".format(local_ip, PORT))
        print()
        print("   手机使用方法:")
        print("   1. 手机连接和电脑相同的WiFi")
        print("   2. 用Chrome/Edge浏览器打开上面的手机访问地址")
        print("   3. 点击浏览器菜单 → 添加到主屏幕/安装应用")
        print("   4. 安装后即可离线使用，不需要电脑运行")
        print()
        print("   按 Ctrl+C 停止服务器")
        print("=" * 50)
        print()
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n服务器已停止")
